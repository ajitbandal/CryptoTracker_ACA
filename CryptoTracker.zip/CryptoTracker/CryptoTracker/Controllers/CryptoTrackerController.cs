﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CryptoTrackerBL.Entities;
using CryptoTrackerBL.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CryptoTracker.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class CryptoTrackerController : ControllerBase
    {
        private ICryptoTrackerBL _cryptoTrackerBL;
        public CryptoTrackerController(ICryptoTrackerBL cryptoTrackerBL)
        {
            this._cryptoTrackerBL = cryptoTrackerBL;
        }


        //https://localhost:44313/CrytoCurrency/GetAllCryptoDetails/
        [HttpGet]
        [Route("GetAllCryptoDetails")]
        public async System.Threading.Tasks.Task<CryptoCurrencyList> GetAllCryptoDetails()
        {
            return await this._cryptoTrackerBL.GetAllCryptoDetailsAsync();
        }



        //https://localhost:44313/CrytoCurrency/GetCryptoDetailsById/1
        [HttpGet]
        [Route("GetCryptoDetailsById/{id:int}")]
        public async System.Threading.Tasks.Task<CryptoCurrency> GetCryptoDetailsById(int id)
        {
            return await this._cryptoTrackerBL.GetCryptoDetailsByIdAsync(id);
        }
    }


}
