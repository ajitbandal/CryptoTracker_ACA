import { Component, OnInit } from '@angular/core';
import { CryptoTrackerService } from '../crypto-tracker.service';
import { ActivatedRoute, Params } from '@angular/router';
import { CurrencyDetails } from '../models/currency-details.model';
@Component({
  selector: 'app-currency-details',
  templateUrl: './currency-details.component.html',
  styleUrls: ['./currency-details.component.css']
})
export class CurrencyDetailsComponent implements OnInit {
  crytoCurrencyDetails: CurrencyDetails;
  private _currencyId: number;
  constructor(private _cryptoTrackerService: CryptoTrackerService, private route: ActivatedRoute) { }

  ngOnInit() {
    this.route.params.subscribe(
      (params: Params) => {
        this._currencyId = params['id'];
        this.getCurrencyDetails();
      }
    );
  }

  getCurrencyDetails() {
    this._cryptoTrackerService.getCrytoCurrencyDetailsById(this._currencyId).subscribe(result => {
      if (result.status == "success")
        this.crytoCurrencyDetails = result.data;
    })
  }

}
