export class Coin {
  public id: number
  public symbol: string
  public name: string
  public description: string
  public iconUrl: string
  public price: number
  public volume: number

}
