"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Coin = /** @class */ (function () {
    function Coin() {
    }
    return Coin;
}());
exports.Coin = Coin;
//# sourceMappingURL=coin.model.js.map