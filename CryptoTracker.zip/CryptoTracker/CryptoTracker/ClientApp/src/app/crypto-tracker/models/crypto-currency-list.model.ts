import { CurrencyList } from "./currency-list.model"

export class CryptoCurrencyList {
  public status: string
  public data: CurrencyList
}
