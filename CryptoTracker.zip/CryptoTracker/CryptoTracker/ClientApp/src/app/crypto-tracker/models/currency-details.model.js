"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var CurrencyDetails = /** @class */ (function () {
    function CurrencyDetails() {
    }
    return CurrencyDetails;
}());
exports.CurrencyDetails = CurrencyDetails;
//# sourceMappingURL=currency-details.model.js.map