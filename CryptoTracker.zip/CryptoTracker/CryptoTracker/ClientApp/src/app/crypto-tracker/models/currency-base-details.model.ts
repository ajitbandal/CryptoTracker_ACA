export class CurrencyBasicDetails {
  public symbol: string
  public sign: string
}
