"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var CurrencyBasicDetails = /** @class */ (function () {
    function CurrencyBasicDetails() {
    }
    return CurrencyBasicDetails;
}());
exports.CurrencyBasicDetails = CurrencyBasicDetails;
//# sourceMappingURL=currency-basic-details.model.js.map