"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var CryptoCurrency = /** @class */ (function () {
    function CryptoCurrency() {
    }
    return CryptoCurrency;
}());
exports.CryptoCurrency = CryptoCurrency;
//# sourceMappingURL=crypto-currency.model.js.map