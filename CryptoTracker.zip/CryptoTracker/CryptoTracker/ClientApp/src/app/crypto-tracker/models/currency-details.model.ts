import { Coin } from "./coin.model";
import { CurrencyBasicDetails } from "./currency-base-details.model";

export class CurrencyDetails {
  public base: CurrencyBasicDetails
  public coin: Coin
}
