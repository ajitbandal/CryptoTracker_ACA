import { Coin } from "./coin.model";
import { CurrencyBasicDetails } from "./currency-base-details.model";

export class CurrencyList {
  public base: CurrencyBasicDetails
  public coins: Coin[]
}
