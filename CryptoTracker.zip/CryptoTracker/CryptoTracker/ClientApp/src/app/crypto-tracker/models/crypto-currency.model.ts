import { CurrencyDetails } from "./currency-details.model"

export class CryptoCurrency {
  public status: string
  public data: CurrencyDetails
}

















