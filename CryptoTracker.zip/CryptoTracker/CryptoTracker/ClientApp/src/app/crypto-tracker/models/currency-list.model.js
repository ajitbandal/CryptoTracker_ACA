"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var CurrencyList = /** @class */ (function () {
    function CurrencyList() {
    }
    return CurrencyList;
}());
exports.CurrencyList = CurrencyList;
//# sourceMappingURL=currency-list.model.js.map