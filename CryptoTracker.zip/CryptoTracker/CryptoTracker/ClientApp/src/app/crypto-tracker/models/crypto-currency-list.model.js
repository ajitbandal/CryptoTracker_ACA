"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var CryptoCurrencyList = /** @class */ (function () {
    function CryptoCurrencyList() {
    }
    return CryptoCurrencyList;
}());
exports.CryptoCurrencyList = CryptoCurrencyList;
//# sourceMappingURL=crypto-currency-list.model.js.map