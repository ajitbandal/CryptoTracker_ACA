import { Injectable, Inject } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { CryptoCurrencyList } from '././models/crypto-currency-list.model';
import { CryptoCurrency } from '././models/crypto-currency.model';


@Injectable({
  providedIn: 'root'
})
export class CryptoTrackerService {

  private _baseUrl: string;
  constructor(private http: HttpClient, @Inject('BASE_URL') baseUrl: string) {
    this._baseUrl = baseUrl;
  }

  getCrytoCurrencyList(): Observable<CryptoCurrencyList> {


    return this.http.get<CryptoCurrencyList>(this._baseUrl + 'CryptoTracker/GetAllCryptoDetails');
  }

  getCrytoCurrencyDetailsById(id: number): Observable<CryptoCurrency> {

    const url = `${this._baseUrl + 'CryptoTracker/GetCryptoDetailsById'}/${id}`;
    return this.http.get<CryptoCurrency>(url)
  }

}
