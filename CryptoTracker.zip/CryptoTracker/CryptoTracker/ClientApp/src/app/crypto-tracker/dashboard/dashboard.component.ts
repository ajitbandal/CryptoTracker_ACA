import { Component, OnInit } from '@angular/core';
import { CryptoTrackerService } from '../crypto-tracker.service';
import { Router } from '@angular/router';
import { CurrencyList } from '../models/currency-list.model';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  constructor(private cryptoTrackerService: CryptoTrackerService, private router: Router) { }
  crytoCurrencyList: CurrencyList;
  ngOnInit() {
    this.getCryptoCurrencyList();
  }
  getCryptoCurrencyList() {

    this.cryptoTrackerService.getCrytoCurrencyList().subscribe(result => {
      if (result.status == "success")
        this.crytoCurrencyList = result.data;
    })
  }

  naviagetToDetailsPage(currencyID: number) {
    this.router.navigateByUrl('currency-details/' + currencyID);
  }
}
