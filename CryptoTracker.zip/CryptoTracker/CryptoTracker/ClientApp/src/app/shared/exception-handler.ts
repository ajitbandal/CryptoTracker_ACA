import { ErrorHandler, Injector, Injectable } from "@angular/core";
import { CustomErrorMessageService } from "./custom-error-message.service";
import { HttpErrorResponse } from "@angular/common/http";

@Injectable({ providedIn: 'root' })
export class ExceptionHandler implements ErrorHandler {
  constructor(private injector: Injector) {
  }
  handleError(error) {
    const customErrorMessageService = this.injector.get(CustomErrorMessageService);

    if (error instanceof HttpErrorResponse) {
      customErrorMessageService.raiseError("It seems that server API is down. Please try after some time.")
    }
    else
      customErrorMessageService.raiseError("Something is Wrong. Please try after some time. ")

    //to hide the messagw after 25 seconds
    setTimeout(
      () => {
        customErrorMessageService.clearError()
      }, 25000)
    //debugger;
    // do something additional stuff with the exception
  }
}
