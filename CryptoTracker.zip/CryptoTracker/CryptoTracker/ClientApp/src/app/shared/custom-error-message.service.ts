import { Injectable } from '@angular/core';
import { Subject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CustomErrorMessageService {
  //to do : Need to create model for Error Details
  private errorDetails = new Subject<any>();
  constructor() { }

  raiseError(message) {
    this.errorDetails.next({ showMessage: true, text: message });
  }
  clearError() {
    this.errorDetails.next({ showMessage: false, text: '' });
  }
  getErrorDetails(): Observable<any> {
    return this.errorDetails.asObservable();
  }
}
