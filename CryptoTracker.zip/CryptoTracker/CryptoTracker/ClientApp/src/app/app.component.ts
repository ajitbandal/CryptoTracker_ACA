import { Component, NgZone } from '@angular/core';
import { CustomErrorMessageService } from './shared/custom-error-message.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})
export class AppComponent {

  showMessage: boolean = false;
  errorMessage: string;

  constructor(private customErrorMessageService: CustomErrorMessageService, private ngZone: NgZone) {
    this.customErrorMessageService.getErrorDetails().subscribe(result => {
      this.ngZone.run(() => {
        // the following setTimeout will not trigger change detection
        this.showMessage = result.showMessage;
        this.errorMessage = result.text;
      });

    });
  }
  title = 'app';
}
