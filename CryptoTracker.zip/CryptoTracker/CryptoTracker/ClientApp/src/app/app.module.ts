import { BrowserModule } from '@angular/platform-browser';
import { NgModule, ErrorHandler } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { NavMenuComponent } from './nav-menu/nav-menu.component';
import { DashboardComponent } from './crypto-tracker/dashboard/dashboard.component';
import { CurrencyDetailsComponent } from './crypto-tracker/currency-details/currency-details.component';
import { ErrorComponent } from './shared/error/error.component';
import { ExceptionHandler } from '../app/shared/exception-handler';
import { InterceptorService } from './shared/InterceptorService';

@NgModule({
  declarations: [
    AppComponent,
    NavMenuComponent,
    DashboardComponent,
    CurrencyDetailsComponent,
    ErrorComponent
  ],
  imports: [
    BrowserModule.withServerTransition({ appId: 'ng-cli-universal' }),
    HttpClientModule,
    FormsModule,
    RouterModule.forRoot([
      { path: '', component: DashboardComponent, pathMatch: 'full' },
      { path: 'dashboard', component: DashboardComponent },
      { path: 'currency-details/:id', component: CurrencyDetailsComponent },
      { path: 'error', component: ErrorComponent },
      { path: '**', component: ErrorComponent }
    ])
  ],
  providers: [{ provide: ErrorHandler, useClass: ExceptionHandler },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: InterceptorService,
      multi: true
    }],
  bootstrap: [AppComponent]
})
export class AppModule { }
