﻿using CryptoTrackerBL.Entities;
using CryptoTrackerBL.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;

namespace CryptoTrackerBL.Implementations
{
    public class CryptoTrackerCoinRankingBL:ICryptoTrackerBL
    {
        //Need to move x-rapidapi-key and x-rapidapi-host in appsetting.json
        HttpRequestMessage _request;
        HttpClient _client;
        IOptions<CoinRankingSettings> _coinRankingSettings;
        public CryptoTrackerCoinRankingBL(IOptions<CoinRankingSettings> coinRankingSettings)
        {
            this._coinRankingSettings = coinRankingSettings;
            //IConfiguration iConfig
            //string xRapidapiKey=iConfig.GetSection("CoinRankingAPIDetails").GetSection("XRapidapiKey").Value;

            this._request = new HttpRequestMessage
            {
                Method = HttpMethod.Get,
                RequestUri = new Uri(this._coinRankingSettings.Value.RapidAPIURL),
                Headers =
                        {
                            { "x-rapidapi-key", this._coinRankingSettings.Value.XRapidapiKey },
                            { "x-rapidapi-host", this._coinRankingSettings.Value.XRapidapiHost },
                        },
            };
            this._client = new HttpClient();

        }
        public async System.Threading.Tasks.Task<CryptoCurrencyList> GetAllCryptoDetailsAsync()
        {


            this._request.RequestUri = new Uri("https://coinranking1.p.rapidapi.com/coins");
            using (var response = await this._client.SendAsync(this._request))
            {
                response.EnsureSuccessStatusCode();
                var jsonString = await response.Content.ReadAsStringAsync();

                var lstCrytoCurrency = JsonConvert.DeserializeObject<CryptoCurrencyList>(jsonString);
                //This is not a proper way
                //To-Do :facing some issue while using coinranking1 url to fetch data with symbols
                lstCrytoCurrency.data.coins = lstCrytoCurrency.data.coins.FindAll(x => x.symbol == "USDT" || x.symbol == "BTC" || x.symbol == "BCH" || x.symbol == "LTC");
                return lstCrytoCurrency;
            }
        }
        public async System.Threading.Tasks.Task<CryptoCurrency> GetCryptoDetailsByIdAsync(int id)
        {

            this._request.RequestUri = new Uri("https://coinranking1.p.rapidapi.com/coin/" + id);
            using (var response = await this._client.SendAsync(this._request))
            {
                response.EnsureSuccessStatusCode();
                var body = await response.Content.ReadAsStringAsync();

                var result = JsonConvert.DeserializeObject<CryptoCurrency>(body);
                return result;
            }
        }
    }
}
