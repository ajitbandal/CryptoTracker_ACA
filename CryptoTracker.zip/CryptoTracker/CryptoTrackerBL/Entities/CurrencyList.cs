﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CryptoTrackerBL.Entities
{
    public class CurrencyList
    {
        public CurrencyBasicDetails @base { get; set; }
        public List<Coin> coins { get; set; }
    }
}
