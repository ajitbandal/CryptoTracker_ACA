﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CryptoTrackerBL.Entities
{
   public class CoinRankingSettings
    {
        public string XRapidapiKey { get; set; }
        public string XRapidapiHost { get; set; }
        public string RapidAPIURL { get; set; }
        
    }
}
