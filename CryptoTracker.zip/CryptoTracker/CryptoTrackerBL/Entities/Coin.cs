﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CryptoTrackerBL.Entities
{
    //There should be an Interfaces for each Entity
    public class Coin
    {
        public int id { get; set; }
        public string symbol { get; set; }
        public string name { get; set; }
        public string description { get; set; }
        public string iconUrl { get; set; }
        public decimal price { get; set; }

        public decimal volume { get; set; }

    }
}
