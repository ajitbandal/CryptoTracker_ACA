﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CryptoTrackerBL.Entities
{
    //To do: Need to move each class into new File
    public class CryptoCurrencyList
    {
        public string status { get; set; }
        public CurrencyList data { get; set; }
    }

    

    

    
}
