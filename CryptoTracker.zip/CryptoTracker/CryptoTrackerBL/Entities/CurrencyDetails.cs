﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CryptoTrackerBL.Entities
{
    public class CurrencyDetails
    {
        public CurrencyBasicDetails @base { get; set; }
        public Coin coin { get; set; }
    }
}
