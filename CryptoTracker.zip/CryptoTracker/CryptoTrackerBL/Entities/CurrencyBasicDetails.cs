﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CryptoTrackerBL.Entities
{
    public class CurrencyBasicDetails
    {
        public string symbol { get; set; }
        public string sign { get; set; }
    }
}
