﻿using CryptoTrackerBL.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace CryptoTrackerBL.Interfaces
{
   public interface ICryptoTrackerBL
    {
        System.Threading.Tasks.Task<CryptoCurrencyList> GetAllCryptoDetailsAsync();
        System.Threading.Tasks.Task<CryptoCurrency> GetCryptoDetailsByIdAsync(int id);
    }
}
